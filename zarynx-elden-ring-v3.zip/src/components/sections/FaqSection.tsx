export { FaqSection } from './HomeSections'
