export { StatsStrip } from './HomeSections'
